package dev.footballClubManager.FootballClubManager.Models;

public enum Role {
    ROLE_ADMIN,
    ROLE_CLIENT
}
